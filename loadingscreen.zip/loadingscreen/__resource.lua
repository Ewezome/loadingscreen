files {
    'index.html',
    'music/load.mp3',
    'img/logo.png',
	'img/bg-1.jpg',
    'img/bg-2.jpg',
    'img/bg-3.jpg',
    'img/bg-4.jpg',
    'img/bg-5.jpg',
    'img/bg-6.jpg',
    'img/bg-7.jpg',
    'img/bg-8.jpg',
    'img/bg-9.jpg',
    'img/bg-10.jpg',
    'img/timeout.png',
	'css/bootstrap.css',
    'css/owl.carousel.css',
	'css/style.css',
    'js/jquery.ajaxchimp.js',
	'js/jquery.backstretch.min.js',
    'js/jquery-1.11.0.min.js',
	'js/lj-safety-first.js',
    'js/owl.carousel.min.js',
}

loadscreen 'index.html'

resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'